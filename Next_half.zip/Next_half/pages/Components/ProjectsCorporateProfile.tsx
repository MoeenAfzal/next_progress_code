import React from 'react'

export default function ProjectsCorporateProfile() {
  return (
    <div className='bg-Project p-10 border-none rounded-lg  mt-8 '>
      <h1 className='mb-5 text-2xl text-[247,255,1]'>Project’s Corporate Profile</h1>
      <p className='text-white text-sm mb-3'>What is Layerzero Labs?</p>
      <p className='text-white text-sm'>Layerzero Labs is the company behind Layerzero protocol. It is incorporated in 2020 in Vancouver Canada. Currently it has the size of 11-50 employees.</p>
      <br />
      <br />
      <table className="w-full">
        <tbody>
          <tr className="">
            <td className="text-sm py-1 border text-white bg text-center">Company Name</td>
            <td className="text-sm py-1 border text-white bg text-center">Layerzero Labs</td>
          </tr>
          <tr className="bg-lgray-100">
            <td className="text-sm py-1 border text-white bg text-center">Year of Incorporation</td>
            <td className="text-sm py-1 border text-white bg text-center">2020</td>
          </tr>
          <tr className="">
            <td className="text-sm py-1 border text-white bg  text-center">Country of Incorporation</td>
            <td className="text-sm py-1 border text-white bg text-center">Canada</td>
          </tr>
          <tr className="bg-lgray-100">
            <td className="text-sm py-1 border text-white bg text-center">Company Size</td>
            <td className="text-sm py-1 border text-white bg text-center">11-50 Employees</td>
          </tr>
        </tbody>
      </table>

      <div className='rfti_analysis mt-5 p-5 border border-blue-300 rounded-lg'>
        <h2 className='text-lg '><span>R</span> RFTF.ai Insights / Analysis</h2>
          <p className='text-sm text-white'>1. Legal / Regulatory Analysis based on Corporate Profile</p>
          <ul >
            <li className='text-sm text-white'>. asdfasdf</li>
            <li className='text-sm text-white'>. asdfasdf</li>
          </ul>

      </div>

    </div>
  )
}
