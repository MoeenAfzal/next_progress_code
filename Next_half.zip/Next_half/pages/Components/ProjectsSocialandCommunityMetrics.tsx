import React from 'react'
import Image from 'next/image';
import twitter1 from '../Images/Twitter.png'
import twitter2 from '../Images/Apple.png'
import twitter3 from '../Images/Behance.png'
import twitter4 from '../Images/Company Logo.png'
import twitter5 from '../Images/Dribbble.png'
import twitter6 from '../Images/Facebook.png'
import twitter7 from '../Images/Figma.png'
import twitter8 from '../Images/Google.png'
import twitter9 from '../Images/Instagram.png'
import twitter10 from '../Images/Snow UI.png'
import twitter11 from '../Images/Tik Tok.png'
import twitter12 from '../Images/Twitter.png'
const Social_media_data = [
    { image: twitter1, numbers: "123,45", text: "followers" },
    { image: twitter2, numbers: "563,45", text: "likes" },
    { image: twitter3, numbers: "763,45", text: "followers" },
    { image: twitter4, numbers: "123,45", text: "followers" },
    { image: twitter5, numbers: "163,45", text: "likes" },
    { image: twitter6, numbers: "123,45", text: "followers" },
    { image: twitter7, numbers: "123,45", text: "likes" },
    { image: twitter8, numbers: "123,45", text: "followers" },
    { image: twitter9, numbers: "123,45", text: "followers" },
    { image: twitter10, numbers: "123,45", text: "likes" },
    { image: twitter11, numbers: "823,45", text: "followers" },
    { image: twitter12, numbers: "923,45", text: "followers" },
]

export default function ProjectsSocialandCommunityMetrics() {
    return (
        <div className='bg-Project p-10 border-none rounded-lg  mt-8 '>
            <h1 className='mb-5 text-2xl text-[247,255,1]'>Project’s Social and Community Metrics</h1>
            <p className="text-white text-sm">Layerzero attracted many attentions in many social media platforms. Layerzero has xx followers on Twitter, and have a xx-people size community in Telegram and Discord.</p>

            <br />
            <div className='flex flex-wrap mb-10'>
                {Social_media_data.map((item, index) => (

                    <div key={index} className="social-media grid text-center w-1/6 justify-center items-center ">
                        
                            <div className="ll grid text-center ">
                            <Image src={item.image} alt="Search Icon" className="h-8 w-6 m-6 mb-2 " />
                                <h3 className='text-sm text-white text-center m-0 p-0'>
                                    <span>{item.numbers}</span>

                                </h3>
                                <p className='text-xs text-gray-300 text-center m-0 p-0'> {item.text}</p>
                            </div>
                        
                    </div>

                ))}
            </div>


            <div className='rfti_analysis mt-5 p-5 border border-blue-300 rounded-lg'>
                <h2 className='text-lg '><span>R</span> RFTF.ai Insights / Analysis

                </h2>
                <p className='text-sm text-white'>The social and community metrics may indicate that xxxx. </p>


            </div>


        </div>
    )
}
