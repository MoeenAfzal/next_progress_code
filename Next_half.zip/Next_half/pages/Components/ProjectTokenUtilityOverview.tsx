import React from 'react'

export default function ProjectTokenUtilityOverview() {
  return (
    <div className='bg-Project p-10 border-none rounded-lg  mt-8 '>
      <h1 className='mb-5 text-2xl text-[247,255,1]'>Project Token Utility Overview</h1>
    
      <p className='text-white text-sm'>LayerZero does not have a token yet. But its primary product is Stargate Finance and STG is its primary token.  STG is the governance token of the Stargate Finance platform.  <br />
According to the Stargate Finance Whitepaper, STG is used for xxxxxxxxxxx</p>
      <br />
      <br />
     

      <div className='rfti_analysis mt-5 p-5 border border-blue-300 rounded-lg'>
        <h2 className='text-lg '><span>R</span> RFTF.ai Insights / Analysis</h2>
          <p className='text-sm text-white'>1. Legal / Regulatory Analysis based on Corporate Profile</p>
          <ul className=''>
            <li className='text-sm text-white'>. asdfasdf</li>
            <li className='text-sm text-white'>. asdfasdf</li>
          </ul>

      </div>

    </div>
  )
}
