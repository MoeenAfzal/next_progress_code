import React from 'react'
import PieChart from './PieChart'

export default function ProjectTokenomics() {
  return (
    <div className='bg-Project p-10 pb-0 border-none rounded-lg  mt-8 '>
      <h1 className='mb-5 text-2xl text-[247,255,1]'>Project Tokenomics</h1>
      <p className="text-white text-sm">Here is a brief overview of STG’s tokenomics: <br />
        1. xxx <br />
        2. xxxx</p>



     <PieChart/>




    </div>
  )
}
