import React from 'react'
import ChartSTG from './ChartSTG'

export default function STGTokenAllocation() {
  return (
    <div>
      <div className='bg-Project p-10 pb-0 border-none rounded-lg  mt-8 '>
      <h1 className='mb-5 text-2xl text-[247,255,1]'>STG Token Allocation</h1>
      <p className="text-white text-sm">According to the whitepaper, STG follows the below token allocation rule: <br />
xxxx</p>



     <ChartSTG/>




    </div>
    </div>
  )
}
