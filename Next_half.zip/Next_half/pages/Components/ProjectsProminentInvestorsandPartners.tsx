import React from 'react'

export default function ProjectsProminentInvestorsandPartners() {
  return (
    <div className='bg-Project p-10 border-none rounded-lg  mt-8 '>
      <h1 className='mb-5 text-2xl text-[247,255,1]'>Project’s Prominent Investors and Partners</h1>

      <br />

      <table className="w-full">
        <tbody>
          <tr className="w-2/2">
            <td className="text-xs py-5 w-1/3 border text-gray-300 bg pl-5 ">Partner Name</td>
            <td className="text-xs py-5 w-1/3 border text-gray-300 bg  pl-5 ">Relationship</td>
            <td className="text-xs py-5 w-1/3 border text-gray-300 bg  pl-5 ">Details</td>

          </tr>
          <tr className="bg-lgray-100">
            <td className="text-xs py-5 border text-gray-300 bg  pl-5 ">Animoca Ventures</td>
            <td className="text-xs py-5 border text-gray-300 bg  pl-5 ">Investors Partnerships</td>
            <td className="text-xs py-5 border text-gray-300 bg  pl-5 "> Seed Round Investor of LayerZero in MMM YYYY;  <br />
              A Round Investor of LayerZero in MMM YYYY; <br />
              B Round Lead Investor of LayerZero in MMM YYYY; <br /> Partnership Jointly Launch LayerZero-Animoca Brands Hackerhouse in MMM YYYY;<br /></td>

          </tr>
          <tr >
            <td className="text-xs py-5 border text-gray-300 bg  pl-5 ">Animoca Ventures</td>
            <td className="text-xs py-5 border text-gray-300 bg  pl-5 ">Investors Partnerships</td>
            <td className="text-xs py-5 border text-gray-300 bg  pl-5 "> Seed Round Investor of LayerZero in MMM YYYY;  <br />
              A Round Investor of LayerZero in MMM YYYY; <br />
              B Round Lead Investor of LayerZero in MMM YYYY; <br /> </td>

          </tr>

        </tbody>
      </table>
      <div className='rfti_analysis mt-5 p-5 border border-blue-300 rounded-lg'>
        <h2 className='text-lg '><span>R</span> RFTF.ai Insights / Analysis
        </h2>
        <p className='text-xs text-gray-300'>Based on Layerzero’s investor profile, we find that xxxx. This may indicate that xxx.</p>


      </div>


    </div>
  )
}
