import React from 'react'
import LineChart from './LineChart'
export default function STGTokenVestingSchedule() {
    return (
        <div>
            <div>
                <div className='bg-Project p-10 pb-0 border-none rounded-lg  mt-8 '>
                    <h1 className='mb-5 text-2xl text-[247,255,1]'>STG Token Vesting Schedule</h1>
                    <p className="text-white text-sm">STG  Release Schedule</p>



                  
              

                    <div className='rfti_analysis mt-5 p-5 border border-blue-300 rounded-lg'>
                        <h2 className='text-lg '><span>R</span> RFTF.ai Insights / Analysis </h2>
                        <p className='text-sm text-white'>. Token utility result in an inflationary or deflationary effect for the token? Inflationary - Bad Point / Negative. Deflationary - Positive</p>
                        <ul className=''>
                            <li className='text-sm text-white'>. asdfasdf</li>
                            
                        </ul>

                    </div>


                </div>
            </div>
        </div>
    )
}
