import React from 'react'

export default function ProjectOverview() {
    return (
        <div className='bg-Project p-10 border-none rounded-lg   '>
            <h1 className='mb-5 text-2xl text-[247,255,1]'>Project Overview</h1>
            <p className='text-white text-sm mb-3'>What is Layerzero?</p>
            <p className='text-white text-sm'>LayerZero is an omnichain interoperability protocol. It enables the realisation of cross-chain applications with a low level communication primitive.</p>
            <br />
            <br />
            <p className='text-white text-sm mb-3'>How does Layerzero work?</p>
            <p className='text-white text-sm'>Layerzero is a user application (ua) configurable on-chain endpoint that runs a uln. layerzero relies on two parties to transfer messages between on-chain endpoints: the oracle and the relayer.</p>

        </div>
    )
}
