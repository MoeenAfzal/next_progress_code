import React from 'react'
import Image from 'next/image';
import logo from "../Images/logo.png"
export default function Navbar() {
  return (
    <div>
        <div className="flex">

        <Image src={logo} alt="Search Icon" className="h-6 w-24 m-8 " />
        
        </div>
      
    </div>
  )
}
