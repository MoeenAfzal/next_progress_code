import React, { Component } from 'react'
import Chart from 'react-google-charts'
const pieData = [
  ['Task', 'Hours per Day'],
  ['Unlocked', 11],
  ['Remaining Locked', 9],
  ['Others', 6]
 
]

  
const pieOptions = {
  
  pieHole: 0.8,
  pieSliceText: 'none'
}
const annotations = [
    {
      text: 'Custom Text',
      textStyle: {
        fontSize: 14,
        color: '#ffffff'
      },
      position: 'center'
    }
  ];
class PieChart extends Component {
  render() {
    return (
      <div className="chart-container  relative">
        
        <Chart
          width={'400px'}
          height={'300px'}
          chartType="PieChart"
          // loader={<div>Loading Chart</div>}
          data={pieData}
          
          options={pieOptions}
         
          rootProps={{ 'data-testid': '3' }}
          className="chart-container"
        />
        <div className="chart-text absolute bg-gray-500 border-dashed border-2 rounded-full  top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white text-center">
          <h2 className='text-white p-1 '>35% <br />
Remaining <br /> locked</h2>
        </div>
      </div>
    )
  }
}
export default PieChart