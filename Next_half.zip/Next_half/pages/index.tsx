import Image from 'next/image'
import { Inter } from 'next/font/google';
import Navbar from './Components/Navbar';
import ProjectOverview from './Components/ProjectOverview';
import ProjectsCorporateProfile from './Components/ProjectsCorporateProfile';
import ProjectTokenUtilityOverview from './Components/ProjectTokenUtilityOverview';
import ProjectsTeamProfile from './Components/ProjectsTeamProfile';
import ProjectsProminentInvestorsandPartners from './Components/ProjectsProminentInvestorsandPartners';
import ProjectsSocialandCommunityMetrics from './Components/ProjectsSocialandCommunityMetrics';
import ProjectTokenomics from './Components/ProjectTokenomics';
import STGTokenAllocation from './Components/STGTokenAllocation';
import STGTokenVestingSchedule from './Components/STGTokenVestingSchedule';
const inter = Inter({ subsets: ['latin'] })

export default function Home() {
  return (
    <div >


      <Navbar />
      <div className="page-content w-4/5 m-auto">
        <ProjectOverview />
        <ProjectsCorporateProfile/>
        <ProjectTokenUtilityOverview/>
        <ProjectsTeamProfile/>
        <ProjectTokenUtilityOverview/>
        <ProjectsProminentInvestorsandPartners/>
        <ProjectsSocialandCommunityMetrics/>
        <ProjectTokenomics/>
        <STGTokenAllocation/>
        <STGTokenVestingSchedule/>
      </div>


    </div>
  )
}
